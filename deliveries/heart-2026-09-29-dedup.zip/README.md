# Heart 新交付包（2026-09-29）

这是交给伙伴安装的**新包**，不是 9 月 22 日旧交付包的覆盖件。当前 `heart-2026-09-29-dedup.zip` 内含 Heart 记忆插件 1.3.1、心情插件 1.5.0、它们共用的日志与状态模块、七份 MaiBot 接入补丁，以及可选的 Live2D 连接文件。伙伴已经有 Live2D 项目，本包**不含形象模型、语音模型或完整 Open-LLM-VTuber 安装环境**。旧的 `heart-2026-09-29.zip` 保留作历史版本，请以带 `dedup` 的新包为准。

## 先弄清楚组成

| 文件夹 | 用途 | 必需吗 |
| --- | --- | --- |
| `plugins/heart_memory_audit/` | 记住、候选、查看、忘记、冲突确认和记忆审计的插件入口 | 是 |
| `plugins/heart_mood/` | 持久心情、话题情绪、风格和评估配置 | 是 |
| `extensions/heart_shared/` | 共用 SQLite 状态和易读日志；安装到 MaiBot 根目录的 `heart_shared/` | 是 |
| `extensions/heart_host_observer.py`、`heart_memory_backend.py`、`heart_memory_scope.py`、`heart_llm_budget.py` | 宿主侧适配；安装到 `src/services/` | 是 |
| `patches/heart-*.patch` | 七份可审查的 MaiBot 底层接入补丁 | 是 |
| `scripts/install_heart_plugins.py` | 先预检、再部署；保留已有插件配置 | 是 |
| `vtuber/` 中列出的 Heart 文件 | 把心情、临时情绪和表情回执接到伙伴已有的 Live2D 项目 | 可选，须人工合并 |
| `tests/test_heart*.py`、`SHA256.json` | 离线回归测试、交付文件指纹 | 建议保留 |

这两项不是独立于 MaiBot 的第二套聊天或长期记忆系统：**原生 A_Memorix 保存/检索长期记忆，Heart 负责入口控制、补充状态与观察日志。** 只复制两个 `plugins/` 目录会缺少宿主接口，不能算安装完成。具体实现和题干对应关系见 [功能覆盖与验收](docs/Heart功能覆盖与验收-2026-09-29.md)。

## 安装前提

1. 先在伙伴电脑上确认实际运行的 MaiBot 目录：应有 `bot.py` 和 `src/services/memory_service.py`。团队仓库提供的上游固定提交见 `upstreams.json`；本补丁以这条代码线及团队的 `patches/maibot.patch` 为基础。任意新版 MaiBot **不保证兼容**。
2. 安装前停掉 MaiBot；NapCat 和已有 Live2D 不必为离线预检而启动。备份目标的两个 Heart 插件配置、`data/heart_observation/` 和安装器可能修改的原生文件。备份只放本机，不传 GitHub。
3. 先看目标项目的 `AGENTS.md`、`git status` 和已有改动。安装器遇到来源不明的修改会停止；不要靠强制覆盖解决。
4. 使用目标 MaiBot 环境的 Python 运行测试和安装器。Python 的 `sqlite3` 已内置，不需要单独安装 SQLite 包。

在**本包根目录**的 PowerShell 终端执行；把示例路径换成伙伴自己的 MaiBot 根目录：

```powershell
& "D:\MaiBot\.venv\Scripts\python.exe" -X utf8 -m unittest discover -s tests -p "test_heart*.py"
& "D:\MaiBot\.venv\Scripts\python.exe" -X utf8 scripts/install_heart_plugins.py --target "D:\MaiBot"
```

第二行只是预检，不会改 MaiBot，也不会连接 QQ、调用模型。若报告补丁冲突，停下并比较实际代码与 `upstreams.json`；不要跳过该补丁。预检通过且备份完成后执行：

```powershell
& "D:\MaiBot\.venv\Scripts\python.exe" -X utf8 scripts/install_heart_plugins.py --target "D:\MaiBot" --apply
& "D:\MaiBot\.venv\Scripts\python.exe" -X utf8 scripts/install_heart_plugins.py --target "D:\MaiBot"
```

最后一行应显示“拟复制/更新 0 个文件；待添加接口 0”。安装器不覆盖目标 `config.toml`；旧配置仍生效，新字段由代码默认值填补，可在 WebUI 修改。安装器不是跨文件事务：如果部署途中发生异常，检查目标状态并使用刚才的备份，不要直接重复强装。

## WebUI 与用户测试

启动**伙伴自己的** MaiBot 后，在“插件管理 → Heart 记忆与对话记录 / Heart 持久化心情状态 → 配置”修改中文设置。记忆主要看“自动记忆与候选区”“新旧记忆冲突”“查看与忘记记忆”；心情主要看“心情数值与恢复”“AI 心情判断”“话题临时情绪”“响应速度与拥堵保护”。配置键保持英文是为了兼容旧设置；页面标题是中文。

- 私聊发送 `/记住 我正在学习Python`，随后 `/我的记忆`；以原生服务返回的已存结果为准，不以机器人口头答应为准。
- 自然聊天中明确要求忘记该事实，按私聊的待确认提示操作；重新 `/我的记忆` 核对。若和旧事实冲突，确认前不能自动替换。
- 群聊发送 `/群回忆` 或 `/群回忆 @成员`：只看当前群可见内容；`/我的记忆` 在群里请求时仅私发本人，不能公开私聊记忆。
- 心情值按会话隔离、持久化；可用关键词或可选 AI 评估。AI 模式使用现有 `utils` 模型，可能增加费用；话题情绪与心情分数分开。群聊可设置累计消息条数和最长等待，减少评估请求。
- 易读日志位于目标 MaiBot 的 `data/heart_observation/logs/QQ/` 与 `logs/Live2D/`，按日期和会话分文件，超过三天自动清理。日志区分“检索候选”“进入模型的参考”“原生实际报告的存储结果”，不能把三者混为一谈。
- 写入前的同义去重会在日志中单独记录“准备写入”“已有记忆”“判断依据”“跳过写入”；只比较同一人物、同一会话的有效旧事实。它不会擅自删除升级前已存在的重复项，清理旧库须先备份并经本人核对。详见 [同义去重修复与旧记忆整理](docs/Heart同义去重修复与旧记忆整理.md)。

本轮离线基线为 **132 项 Heart 测试通过**，另有 Live2D 控制器离线测试；安装器对当前运行版本的只读预检通过。离线通过不代表伙伴机器的真实模型、QQ 或 Live2D 已验收。首次联机测试要取得伙伴许可，并用虚构信息；不要把真实聊天、密钥、QQ 登录态、数据库或日志上传。

## 已有 Live2D 怎么接

伙伴已经接入 Live2D：**不要用本包的 `vtuber/` 整目录覆盖她的项目**。先比较同名文件和版本，再把 Heart 桥及对应的前后端改动合并。`HEART_MAIBOT_ROOT` 指向她自己的 MaiBot 根目录；只有启用该变量，Heart 桥才读取本机 Live2D 会话心情并驱动表情。`vtuber/heart_bridge.py` 提供本机状态与动作回执接口，前端模块展示数值/临时情绪并报告“已执行/失败”；表演请求不会改真实心情。详细顺序见 [话题情绪与 Live2D 接入](docs/Heart话题情绪与Live2D接入.md)。不启用桥时，两个 Heart 插件的 QQ 功能仍可独立运行。

## 回退与边界

先关闭 MaiBot、备份现状。若只是 AI 判断不合适，可在 WebUI 关闭 `ai.enabled` 或 `emotions.enabled`；不必删除数据库。完整卸载需要依据安装前备份逐文件恢复，或在确认当前原生文件没有伙伴后续改动后按**逆序**检查并撤销七份补丁；不能整目录覆盖 `src/`。本包不会自动卸载、删除原生记忆或擦除历史审计。

“忘记”会使相应长期记忆不再可用，**不会立刻擦除审计日志中的历史原话**（当前日志按用户要求保留约三天）。记忆检索进入模型输入也不能证明模型在最终回答里采纳了它。语音、工具行动的通用审计和 Lv4 的“10 秒首反馈”不在本包验收范围。

给协助安装的 AI 助手的逐项指令见 [GPT 安装交接](docs/Heart给同伴GPT安装-2026-09-29.md)。
