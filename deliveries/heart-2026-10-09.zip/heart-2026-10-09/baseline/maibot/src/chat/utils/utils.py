from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, List, Optional, Tuple

import ast
import json
import os
import random
import re
import time

from src.chat.message_receive.chat_manager import chat_manager as _chat_manager
from src.chat.message_receive.message import SessionMessage
from src.common.data_models.message_component_data_model import AtComponent
from src.common.logger import get_logger
from src.config.config import global_config
from src.person_info.person_info import Person
from src.services.bot_account_service import get_bot_accounts
from src.services.embedding_service import EmbeddingServiceClient

from .typo_generator import ChineseTypoGenerator

if TYPE_CHECKING:
    from src.common.data_models.chat_target_info_data_model import ChatTargetInfo

logger = get_logger("chat_utils")
_warned_unconfigured_platforms: set[str] = set()


@dataclass(frozen=True)
class ProcessedResponseSegment:
    """回复后处理产生的单条消息及其发送提示。"""

    text: str
    quote_previous: bool = False


def is_english_letter(char: str) -> bool:
    """检查字符是否为英文字母（忽略大小写）"""
    return "a" <= char.lower() <= "z"


def parse_platform_accounts(platforms: list[str]) -> dict[str, str]:
    """解析 platforms 列表，返回平台到账号的映射

    Args:
        platforms: 格式为 ["platform:account"] 的列表，如 ["tg:123456789", "wx:wxid123"]

    Returns:
        字典，键为平台名，值为账号
    """
    result: dict[str, str] = {}
    for platform_entry in platforms:
        if ":" in platform_entry:
            platform_name, account = platform_entry.split(":", 1)
            normalized_platform = platform_name.lower().strip()
            account_str = account.strip()
            if normalized_platform and account_str:
                result[normalized_platform] = account_str
    return result


def _get_configured_qq_account() -> str:
    qq_account = str(getattr(global_config.bot, "qq_account", "")).strip()
    if qq_account in {"", "0"}:
        return ""
    return qq_account


def get_bot_account(platform: str, preferred_account_id: Optional[str] = None) -> str:
    """解析单个 Bot 账号；多账号且无会话归属时拒绝猜测。"""

    preferred = str(preferred_account_id or "").strip()
    if preferred:
        return preferred
    accounts = get_bot_accounts(platform)
    if len(accounts) == 1:
        return next(iter(accounts))
    if len(accounts) > 1:
        logger.error(f"平台 {platform} 存在多个 Bot 账号，缺少聊天流 account_id，无法选择发送身份")
    return ""


def get_configured_bot_accounts() -> dict[str, str]:
    """读取 legacy 发送链使用的备用配置账号，不包含数据库身份。"""

    bot_accounts: dict[str, str] = {}
    qq_account = _get_configured_qq_account()
    if qq_account:
        primary_platform = str(global_config.bot.platform or "qq").strip().lower()
        bot_accounts[primary_platform] = qq_account

    platforms_list = getattr(global_config.bot, "platforms", []) or []
    platform_accounts = parse_platform_accounts(platforms_list)

    for platform_name, account in platform_accounts.items():
        if platform_name in {"qq", "webui"}:
            continue
        bot_accounts[platform_name] = account

    return bot_accounts


def is_bot_self(platform: str, user_id: str) -> bool:
    """判断给定的平台和用户ID是否是机器人自己

    这个函数统一处理所有平台（包括 QQ、Telegram、WebUI 等）的机器人识别逻辑。

    Args:
        platform: 消息平台（如 "qq", "telegram", "webui" 等）
        user_id: 用户ID

    Returns:
        bool: 如果是机器人自己则返回 True，否则返回 False
    """
    normalized_platform = str(platform or "").strip().lower()
    if not normalized_platform or not user_id:
        return False

    # 将 user_id 转为字符串进行比较
    user_id_str = str(user_id).strip()
    if not user_id_str:
        return False

    bot_accounts = get_bot_accounts(normalized_platform)
    if bot_accounts:
        return user_id_str in bot_accounts

    if normalized_platform not in _warned_unconfigured_platforms:
        _warned_unconfigured_platforms.add(normalized_platform)
        logger.warning(f"平台 {normalized_platform} 未配置机器人账号，无法判断用户 {user_id_str} 是否为机器人自己")
    return False


def _has_at_component_targeting_bot(message: SessionMessage, platform: str) -> bool:
    """检查消息中的结构化 @ 组件是否直接指向当前 bot。"""

    raw_message = getattr(message, "raw_message", None)
    for component in getattr(raw_message, "components", []) or []:
        if isinstance(component, AtComponent) and is_bot_self(platform, component.target_user_id):
            return True
    return False


def is_mentioned_bot_in_message(message: SessionMessage) -> tuple[bool, bool, float]:
    """检查消息是否提到了机器人（统一多平台实现）"""
    text = message.processed_plain_text or ""
    platform = str(message.platform or "").strip().lower()

    current_accounts = get_bot_accounts(platform)

    nickname = str(global_config.bot.nickname or "")
    alias_names = list(getattr(global_config.bot, "alias_names", []) or [])
    keywords = [nickname] + alias_names

    reply_probability = 0.0
    is_at = False
    is_mentioned = False

    # 1) 直接的 additional_config 标记
    add_cfg = getattr(message.message_info, "additional_config", None) or {}
    if isinstance(add_cfg, dict):
        if add_cfg.get("at_bot") or add_cfg.get("is_mentioned"):
            is_mentioned = True
            if add_cfg.get("at_bot"):
                is_at = True
            # 当提供数值型 is_mentioned 时，当作概率提升；布尔提及标记只负责标记命中。
            raw_mention_boost = add_cfg.get("is_mentioned")
            if raw_mention_boost not in (None, "") and not isinstance(raw_mention_boost, bool):
                reply_probability = float(raw_mention_boost)

    # 2) 已经在上游设置过的 message.is_at / message.is_mentioned
    if getattr(message, "is_at", False):
        is_at = True
        is_mentioned = True
    if getattr(message, "is_mentioned", False):
        is_mentioned = True

    # 3) 扫描分段：是否包含 mention_bot（适配器插入）
    def _has_mention_bot(seg) -> bool:
        try:
            if seg is None:
                return False
            if getattr(seg, "type", None) == "mention_bot":
                return True
            if getattr(seg, "type", None) == "seglist":
                for s in getattr(seg, "data", []) or []:
                    if _has_mention_bot(s):
                        return True
            return False
        except Exception:
            return False

    if _has_mention_bot(getattr(message, "message_segment", None)):
        is_at = True
        is_mentioned = True

    # 4) 结构化 @ 组件检测。处理后的文本可能只剩群名片，不能依赖文本里的显示名判断。
    if not is_at and _has_at_component_targeting_bot(message, platform):
        is_at = True
        is_mentioned = True

    # 5) 统一的 @ 检测逻辑
    if current_accounts and not is_at and not is_mentioned:
        for current_account in current_accounts:
            pattern = (
                rf"@<(.+?):{re.escape(current_account)}>"
                if platform == "qq"
                else rf"@{re.escape(current_account)}(\b|$)"
            )
            if re.search(pattern, text, flags=re.IGNORECASE):
                is_at = True
                is_mentioned = True
                break

    # 6) 统一的回复检测逻辑
    if not is_mentioned:
        # 通用回复格式：包含 "(你)" 或 "（你）"
        if re.search(r"\[回复 .*?\(你\)：", text) or re.search(r"\[回复 .*?（你）：", text):
            is_mentioned = True
        # ID 形式的回复检测
        elif current_accounts:
            for current_account in current_accounts:
                if re.search(rf"\[回复 (.+?)\({re.escape(current_account)}\)：(.+?)\]，说：", text):
                    is_mentioned = True
                    break
                if re.search(
                    rf"\[回复<(.+?)(?=:{re.escape(current_account)}>)\:{re.escape(current_account)}>：(.+?)\]，说：",
                    text,
                ):
                    is_mentioned = True
                    break

    # 7) 名称/别名 提及（去除 @/回复标记后再匹配）
    if not is_mentioned and keywords:
        msg_content = text
        # 去除各种 @ 与 回复标记，避免误判
        msg_content = re.sub(r"@(.+?)（(\d+)）", "", msg_content)
        msg_content = re.sub(r"@<(.+?)(?=:(\d+))\:(\d+)>", "", msg_content)
        msg_content = re.sub(r"\[回复 (.+?)\(((\d+)|未知id|你)\)：(.+?)\]，说：", "", msg_content)
        msg_content = re.sub(r"\[回复<(.+?)(?=:(\d+))\:(\d+)>：(.+?)\]，说：", "", msg_content)
        for kw in keywords:
            if kw and kw in msg_content:
                is_mentioned = True
                break

    # 8) 概率设置
    reply_timing_config = global_config.chat.reply_timing
    if is_at and reply_timing_config.inevitable_at_reply:
        reply_probability = 1.0
        logger.debug("被@，回复概率设置为100%")
    elif is_mentioned and reply_timing_config.mentioned_bot_reply:
        reply_probability = max(reply_probability, 1.0)
        logger.debug("被提及，回复概率设置为100%")

    return is_mentioned, is_at, reply_probability


async def get_embedding(text: str, request_type: str = "embedding") -> Optional[List[float]]:
    """获取文本的嵌入向量。

    Args:
        text: 待编码的文本内容。
        request_type: 当前请求的业务类型标识。

    Returns:
        Optional[List[float]]: 成功时返回嵌入向量，失败时返回 `None`。
    """
    embedding_client = EmbeddingServiceClient(task_name="embedding", request_type=request_type)
    try:
        embedding_result = await embedding_client.embed_text(text)
        embedding = embedding_result.embedding
    except Exception as e:
        logger.error(f"获取embedding失败: {str(e)}")
        embedding = None
    return embedding


def split_into_sentences_w_remove_punctuation(text: str) -> list[str]:
    """将文本分割成句子，并根据概率合并
    1. 识别分割点（, ， 。 ; 空格），但如果分割点左右都是英文字母则不分割。
    2. 将文本分割成 (内容, 分隔符) 的元组。
    3. 根据原始文本长度计算合并概率，概率性地合并相邻段落。
    注意：此函数假定颜文字已在上层被保护。
    Args:
        text: 要分割的文本字符串 (假定颜文字已被保护)
    Returns:
        List[str]: 分割和合并后的句子列表
    """
    # 预处理：处理多余的换行符
    # 1. 将连续的换行符替换为单个换行符（保留换行符用于分割）
    text = re.sub(r"\n\s*\n+", "\n", text)
    # 2. 处理换行符和其他分隔符的组合（保留换行符，删除其他分隔符）
    text = re.sub(r"\n\s*([，,。;\s])", r"\n\1", text)
    text = re.sub(r"([，,。;\s])\s*\n", r"\1\n", text)

    # 处理两个汉字中间的换行符（保留换行符，不替换为句号，让换行符强制分割）
    # text = re.sub(r"([\u4e00-\u9fff])\n([\u4e00-\u9fff])", r"\1。\2", text)  # 注释掉，保留换行符用于分割

    len_text = len(text)
    if len_text < 3:
        return list(text) if random.random() < 0.01 else [text]

    # 先标记哪些位置位于成对引号内部，避免在引号内部进行句子分割
    # 支持的引号包括：中英文单/双引号和常见中文书名号/引号
    quote_chars = {
        '"',
        "'",
        "“",
        "”",
        "‘",
        "’",
        "「",
        "」",
        "『",
        "』",
    }
    inside_quote = [False] * len_text
    in_quote = False
    current_quote_char = ""
    for idx, ch in enumerate(text):
        if ch in quote_chars:
            # 遇到引号时切换状态（英文引号本身开闭相同，用同一个字符表示）
            if not in_quote:
                in_quote = True
                current_quote_char = ch
                inside_quote[idx] = False
            else:
                # 只有遇到同一类引号才视为关闭
                if ch == current_quote_char or ch in {'"', "'"} and current_quote_char in {'"', "'"}:
                    in_quote = False
                    current_quote_char = ""
                inside_quote[idx] = False
        else:
            inside_quote[idx] = in_quote

    # 定义分隔符（包含换行符）
    separators = {"，", ",", " ", "。", ";", "\n"}
    segments = []
    current_segment = ""

    # 1. 分割成 (内容, 分隔符) 元组
    i = 0
    while i < len(text):
        char = text[i]
        if char in separators:
            # 引号内部一律不作为分割点（包括换行）
            if inside_quote[i]:
                can_split = False
            else:
                # 换行符在不在引号内时都强制分割
                if char == "\n":
                    can_split = True
                else:
                    # 检查分割条件
                    can_split = True
                    # 检查分隔符左右是否有冒号（中英文），如果有则不分割
                    if i > 0:
                        prev_char = text[i - 1]
                        if prev_char in {":", "："}:
                            can_split = False
                    if i < len(text) - 1:
                        next_char = text[i + 1]
                        if next_char in {":", "："}:
                            can_split = False

                    # 如果左右没有冒号，再检查空格的特殊情况
                    if can_split and char == " " and i > 0 and i < len(text) - 1:
                        prev_char = text[i - 1]
                        next_char = text[i + 1]
                        dash_chars = {"-", "—"}
                        if prev_char in dash_chars or next_char in dash_chars:
                            can_split = False
                        else:
                            # 不分割数字和数字、数字和英文、英文和数字、英文和英文之间的空格
                            prev_is_alnum = prev_char.isdigit() or is_english_letter(prev_char)
                            next_is_alnum = next_char.isdigit() or is_english_letter(next_char)
                            if prev_is_alnum and next_is_alnum:
                                can_split = False

            if can_split:
                # 只有当当前段不为空时才添加
                if current_segment:
                    segments.append((current_segment, char))
                # 如果当前段为空，但分隔符是空格或换行符，则也添加一个空段（保留分隔符）
                elif char in {" ", "\n"}:
                    segments.append(("", char))
                current_segment = ""
            else:
                # 不分割，将分隔符加入当前段
                current_segment += char
        else:
            current_segment += char
        i += 1

    # 添加最后一个段（没有后续分隔符）
    if current_segment:
        segments.append((current_segment, ""))

    # 过滤掉完全空的段（内容和分隔符都为空）
    segments = [(content, sep) for content, sep in segments if content or sep]

    # 如果分割后为空（例如，输入全是分隔符且不满足保留条件），恢复颜文字并返回
    if not segments:
        return [text] if text else []  # 如果原始文本非空，则返回原始文本（可能只包含未被分割的字符或颜文字占位符）

    # 2. 概率合并
    if len_text < 12:
        split_strength = 0.2
    elif len_text < 32:
        split_strength = 0.6
    else:
        split_strength = 0.7
    # 合并概率与分割强度相反
    merge_probability = 1.0 - split_strength

    merged_segments = []
    idx = 0
    while idx < len(segments):
        current_content, current_sep = segments[idx]

        # 检查是否可以与下一段合并
        # 条件：不是最后一段，且随机数小于合并概率，且当前段有内容（避免合并空段）
        if (
            idx + 1 < len(segments)
            and current_content
            and current_sep != "\n"
            and random.random() < merge_probability
        ):
            next_content, next_sep = segments[idx + 1]
            # 合并: (内容1 + 分隔符1 + 内容2, 分隔符2)
            # 只有当下一段也有内容时才合并文本，否则只传递分隔符
            if next_content:
                merged_content = current_content + current_sep + next_content
                merged_segments.append((merged_content, next_sep))
            else:  # 下一段内容为空，只保留当前内容和下一段的分隔符
                merged_segments.append((current_content, next_sep))

            idx += 2  # 跳过下一段，因为它已被合并
        else:
            # 不合并，直接添加当前段
            merged_segments.append((current_content, current_sep))
            idx += 1

    # 提取最终的句子内容
    final_sentences = [content for content, sep in merged_segments if content]  # 只保留有内容的段

    # 清理可能引入的空字符串和仅包含空白的字符串
    final_sentences = [
        s for s in final_sentences if s.strip()
    ]  # 过滤掉空字符串以及仅包含空白（如换行符、空格）的字符串
    final_sentences = [
        normalized_sentence
        for sentence in final_sentences
        if (normalized_sentence := re.sub(r"[^\S\r\n]*[\r\n]+[^\S\r\n]*", " ", sentence).strip())
    ]

    logger.debug(f"分割并合并后的句子: {final_sentences}")
    return final_sentences


def merge_sentences_to_max_count(sentences: list[str], max_count: int) -> list[str]:
    """按顺序将分句合并到指定条数以内。"""

    if len(sentences) <= max_count:
        return sentences

    merged_sentences: list[str] = []
    sentence_count = len(sentences)
    start_index = 0
    for group_index in range(max_count):
        remaining_sentences = sentence_count - start_index
        remaining_groups = max_count - group_index
        group_size = (remaining_sentences + remaining_groups - 1) // remaining_groups
        merged_sentences.append("".join(sentences[start_index : start_index + group_size]))
        start_index += group_size

    return merged_sentences


def _merge_processed_segments_to_max_count(
    segments: list[ProcessedResponseSegment],
    max_count: int,
) -> list[ProcessedResponseSegment]:
    """压缩回复段数量，并优先让需要引用的纠正内容保持在消息开头。"""

    if len(segments) <= max_count:
        return segments
    if max_count <= 0:
        return []

    segment_count = len(segments)
    required_starts = [index for index, segment in enumerate(segments) if index > 0 and segment.quote_previous]
    group_starts = {0, *required_starts[: max_count - 1]}

    # 在保留纠正消息边界后，沿用原来的均匀分组策略填充其余可用分组。
    evenly_spaced_starts: list[int] = []
    start_index = 0
    for group_index in range(max_count):
        remaining_segments = segment_count - start_index
        remaining_groups = max_count - group_index
        group_size = (remaining_segments + remaining_groups - 1) // remaining_groups
        evenly_spaced_starts.append(start_index)
        start_index += group_size

    for candidate_start in evenly_spaced_starts:
        if len(group_starts) >= max_count:
            break
        group_starts.add(candidate_start)

    sorted_starts = sorted(group_starts)
    merged_segments: list[ProcessedResponseSegment] = []
    for group_index, group_start in enumerate(sorted_starts):
        group_end = sorted_starts[group_index + 1] if group_index + 1 < len(sorted_starts) else segment_count
        group = segments[group_start:group_end]
        merged_segments.append(
            ProcessedResponseSegment(
                text="".join(segment.text for segment in group),
                quote_previous=group[0].quote_previous,
            )
        )

    return merged_segments


def random_remove_punctuation(text: str) -> str:
    """随机处理标点符号，模拟人类打字习惯

    Args:
        text: 要处理的文本

    Returns:
        str: 处理后的文本
    """
    result = ""
    text_len = len(text)

    for i, char in enumerate(text):
        if char == "。" and i == text_len - 1:  # 结尾的句号
            if random.random() > 0.1:  # 90%概率删除结尾句号
                continue
        elif char == "，":
            rand = random.random()
            if rand < 0.05:  # 5%概率删除逗号
                continue
            elif rand < 0.25:  # 20%概率把逗号变成空格
                result += " "
                continue
        result += char
    return result


def _get_random_default_reply() -> str:
    """获取随机默认回复"""
    default_replies = [
        f"{global_config.bot.nickname}不知道哦",
        f"{global_config.bot.nickname}不知道",
        "不知道哦",
        "不知道",
        "不晓得",
        "懒得说",
        "()",
    ]
    return random.choice(default_replies)


def process_llm_response_segments(
    text: str,
    enable_splitter: bool = True,
    enable_chinese_typo: bool = True,
) -> list[ProcessedResponseSegment]:
    """处理回复文本，并保留错别字纠正消息的引用提示。"""

    if not global_config.response_post_process.enable_response_post_process:
        return [ProcessedResponseSegment(text)]

    # 先保护颜文字
    if global_config.response_splitter.enable_kaomoji_protection:
        protected_text, kaomoji_mapping = protect_kaomoji(text)
        logger.debug(f"保护颜文字后的文本: {protected_text}")
    else:
        protected_text = text
        kaomoji_mapping = {}
    # 提取被 () 或 [] 或 （）包裹且包含中文的内容
    pattern = re.compile(r"[(\[（](?=.*[一-鿿]).*?[)\]）]")
    _extracted_contents = pattern.findall(protected_text)  # 在保护后的文本上查找
    # 去除 () 和 [] 及其包裹的内容
    cleaned_text = pattern.sub("", protected_text)

    if cleaned_text == "":
        return [ProcessedResponseSegment("呃呃")]

    logger.debug(f"{text}去除括号处理后的文本: {cleaned_text}")

    # 对清理后的文本进行进一步处理
    max_length = global_config.response_splitter.max_length * 2
    max_sentence_num = global_config.response_splitter.max_sentence_num
    max_split_num = global_config.response_splitter.max_split_num
    # 如果基本上是中文，则进行长度过滤
    if get_western_ratio(cleaned_text) < 0.1 and len(cleaned_text) > max_length:
        logger.warning(f"回复过长 ({len(cleaned_text)} 字符)，返回默认回复")
        return [ProcessedResponseSegment(_get_random_default_reply())]

    typo_generator = ChineseTypoGenerator(
        error_rate=global_config.chinese_typo.error_rate,
        min_freq=global_config.chinese_typo.min_freq,
        tone_error_rate=global_config.chinese_typo.tone_error_rate,
        word_replace_rate=global_config.chinese_typo.word_replace_rate,
    )

    if global_config.response_splitter.enable and enable_splitter:
        split_sentences = split_into_sentences_w_remove_punctuation(cleaned_text)
    else:
        split_sentences = [cleaned_text]

    segments: list[ProcessedResponseSegment] = []
    for sentence in split_sentences:
        if global_config.chinese_typo.enable and enable_chinese_typo:
            typoed_text, typo_corrections = typo_generator.create_typo_sentence(sentence)
            if typo_corrections:
                # 50%概率新增正确字/词，50%概率用正确分句替换错别字分句
                if random.random() < 0.5:
                    quote_previous = (
                        global_config.chinese_typo.enable_correction_quote
                        and random.random() < global_config.chinese_typo.correction_quote_probability
                    )
                    segments.append(ProcessedResponseSegment(typoed_text))
                    segments.append(
                        ProcessedResponseSegment(
                            typo_corrections,
                            quote_previous=quote_previous,
                        )
                    )
                else:
                    # 用正确的分句替换错别字分句
                    segments.append(ProcessedResponseSegment(sentence))
            else:
                segments.append(ProcessedResponseSegment(typoed_text))
        else:
            segments.append(ProcessedResponseSegment(sentence))

    if len(segments) > max_sentence_num:
        if global_config.response_splitter.enable_overflow_return_all:
            logger.warning(f"分割后消息数量过多 ({len(segments)} 条)，直接返回原文")
            segments = [ProcessedResponseSegment(cleaned_text)]
        else:
            logger.warning(f"分割后消息数量过多 ({len(segments)} 条)，返回默认回复")
            return [ProcessedResponseSegment(_get_random_default_reply())]

    segments = _merge_processed_segments_to_max_count(segments, max_split_num)

    # if extracted_contents:
    #     for content in extracted_contents:
    #         sentences.append(content)

    # 在所有句子处理完毕后，对包含占位符的列表进行恢复
    if global_config.response_splitter.enable_kaomoji_protection:
        recovered_sentences = recover_kaomoji([segment.text for segment in segments], kaomoji_mapping)
        segments = [
            ProcessedResponseSegment(
                text=recovered_text,
                quote_previous=segment.quote_previous,
            )
            for segment, recovered_text in zip(segments, recovered_sentences, strict=True)
        ]

    return segments


def process_llm_response(text: str, enable_splitter: bool = True, enable_chinese_typo: bool = True) -> list[str]:
    """处理回复文本，并返回兼容旧调用链的纯文本列表。"""

    return [
        segment.text
        for segment in process_llm_response_segments(
            text,
            enable_splitter=enable_splitter,
            enable_chinese_typo=enable_chinese_typo,
        )
    ]


def calculate_typing_time(
    input_string: str,
    # thinking_start_time: float,
    chinese_time: float = 0.3,
    english_time: float = 0.15,
    is_emoji: bool = False,
) -> float:
    """
    计算输入字符串所需的时间，中文和英文字符有不同的输入时间
        input_string (str): 输入的字符串
        chinese_time (float): 中文字符的输入时间，默认为0.2秒
        english_time (float): 英文字符的输入时间，默认为0.1秒
        is_emoji (bool): 是否为emoji，默认为False

    特殊情况：
    - 如果只有一个中文字符，将使用3倍的中文输入时间
    - 在所有输入结束后，额外加上回车时间0.3秒
    - 如果is_emoji为True，将使用固定1秒的输入时间
    """
    # chinese_time *= 1 / typing_speed_multiplier
    # english_time *= 1 / typing_speed_multiplier
    # 计算中文字符数
    chinese_chars = sum("\u4e00" <= char <= "\u9fff" for char in input_string)

    # 如果只有一个中文字符，使用3倍时间
    if chinese_chars == 1 and len(input_string.strip()) == 1:
        return chinese_time * 3 + 0.3  # 加上回车时间

    # 正常计算所有字符的输入时间
    total_time = 0.0
    for char in input_string:
        total_time += chinese_time if "\u4e00" <= char <= "\u9fff" else english_time
    if is_emoji:
        total_time = 1

    typing_speed = global_config.response_post_process.typing_speed
    if typing_speed <= 0:
        return 0
    total_time *= typing_speed

    # if time.time() - thinking_start_time > 10:
    #     total_time = 1

    # print(f"thinking_start_time:{thinking_start_time}")
    # print(f"nowtime:{time.time()}")
    # print(f"nowtime - thinking_start_time:{time.time() - thinking_start_time}")
    # print(f"{total_time}")

    return total_time  # 加上回车时间


def truncate_message(message: str, max_length=20) -> str:
    """截断消息，使其不超过指定长度"""
    return f"{message[:max_length]}..." if len(message) > max_length else message


def protect_kaomoji(sentence):
    """ "
    识别并保护句子中的颜文字（含括号与无括号），将其替换为占位符，
    并返回替换后的句子和占位符到颜文字的映射表。
    Args:
        sentence (str): 输入的原始句子
    Returns:
        tuple: (处理后的句子, {占位符: 颜文字})
    """
    kaomoji_pattern = re.compile(
        r"("
        r"[(\[（【]"  # 左括号
        r"[^()\[\]（）【】]*?"  # 非括号字符（惰性匹配）
        r"[^一-龥a-zA-Z0-9\s]"  # 非中文、非英文、非数字、非空格字符（必须包含至少一个）
        r"[^()\[\]（）【】]*?"  # 非括号字符（惰性匹配）
        r"[)\]）】"  # 右括号
        r"]"
        r")"
        r"|"
        r"([▼▽・ᴥω･﹏^><≧≦￣｀´∀ヮДд︿﹀へ｡ﾟ╥╯╰︶︹•⁄]{2,15})"
    )

    kaomoji_matches = kaomoji_pattern.findall(sentence)
    placeholder_to_kaomoji = {}

    for match in kaomoji_matches:
        kaomoji = match[0] or match[1]
        if kaomoji.startswith("[表情包") and kaomoji.endswith("]"):
            continue
        idx = len(placeholder_to_kaomoji)
        placeholder = f"__KAOMOJI_{idx}__"
        sentence = sentence.replace(kaomoji, placeholder, 1)
        placeholder_to_kaomoji[placeholder] = kaomoji

    return sentence, placeholder_to_kaomoji


def recover_kaomoji(sentences, placeholder_to_kaomoji):
    """
    根据映射表恢复句子中的颜文字。
    Args:
        sentences (list): 含有占位符的句子列表
        placeholder_to_kaomoji (dict): 占位符到颜文字的映射表
    Returns:
        list: 恢复颜文字后的句子列表
    """
    recovered_sentences = []
    for sentence in sentences:
        for placeholder, kaomoji in placeholder_to_kaomoji.items():
            sentence = sentence.replace(placeholder, kaomoji)
        recovered_sentences.append(sentence)
    return recovered_sentences


def get_western_ratio(paragraph):
    """计算段落中字母数字字符的西文比例
    原理：检查段落中字母数字字符的西文比例
    通过is_english_letter函数判断每个字符是否为西文
    只检查字母数字字符，忽略标点符号和空格等非字母数字字符

    Args:
        paragraph: 要检查的文本段落

    Returns:
        float: 西文字符比例(0.0-1.0)，如果没有字母数字字符则返回0.0
    """
    alnum_chars = [char for char in paragraph if char.isalnum()]
    if not alnum_chars:
        return 0.0

    western_count = sum(bool(is_english_letter(char)) for char in alnum_chars)
    return western_count / len(alnum_chars)


def translate_timestamp_to_human_readable(timestamp: float, mode: str = "normal") -> str:
    # sourcery skip: merge-comparisons, merge-duplicate-blocks, switch
    """将时间戳转换为人类可读的时间格式

    Args:
        timestamp: 时间戳
        mode: 转换模式，"normal"为标准格式，"relative"为相对时间格式

    Returns:
        str: 格式化后的时间字符串
    """
    if mode == "normal":
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp))
    elif mode == "normal_no_YMD":
        return time.strftime("%H:%M:%S", time.localtime(timestamp))
    elif mode == "relative":
        now = time.time()
        diff = now - timestamp

        if diff < 20:
            return "刚刚"
        elif diff < 60:
            return f"{int(diff)}秒前"
        elif diff < 3600:
            return f"{int(diff / 60)}分钟前"
        elif diff < 86400:
            return f"{int(diff / 3600)}小时前"
        elif diff < 86400 * 2:
            return f"{int(diff / 86400)}天前"
        else:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp)) + ":"
    else:  # mode = "lite" or unknown
        # 只返回时分秒格式
        return time.strftime("%H:%M:%S", time.localtime(timestamp))


def get_chat_type_and_target_info(chat_id: str) -> Tuple[bool, Optional["ChatTargetInfo"]]:
    """
    获取聊天类型（是否群聊）和私聊对象信息。

    Args:
        chat_id: 聊天流ID

    Returns:
        Tuple[bool, Optional[Dict]]:
            - bool: 是否为群聊 (True 是群聊, False 是私聊或未知)
            - Optional[Dict]: 如果是私聊，包含对方信息的字典；否则为 None。
            字典包含: platform, user_id, user_nickname, person_id, person_name
    """
    is_group_chat = False  # Default to private/unknown
    chat_target_info = None

    try:
        if chat_stream := _chat_manager.get_session_by_session_id(chat_id):
            if chat_stream.is_group_session:
                is_group_chat = True
                chat_target_info = None  # Explicitly None for group chat
            elif chat_stream.user_id:  # It's a private chat
                is_group_chat = False
                platform: str = chat_stream.platform
                user_id: str = chat_stream.user_id

                # Try to get nickname from context
                user_nickname = None
                if (
                    chat_stream.context
                    and chat_stream.context.message
                    and chat_stream.context.message.message_info.user_info
                ):
                    user_nickname = chat_stream.context.message.message_info.user_info.user_nickname

                from src.common.data_models.chat_target_info_data_model import ChatTargetInfo  # 解决循环导入问题

                # Initialize target_info with basic info
                target_info = ChatTargetInfo(
                    platform=platform,
                    user_id=user_id,
                    session_nickname=user_nickname or "",
                    person_id=None,
                    person_name=None,
                )

                # Try to fetch person info
                try:
                    person = Person(platform=platform, user_id=user_id)
                    if not person.is_known:
                        logger.warning(f"用户 {user_nickname} 尚未认识")
                        # 如果用户尚未认识，则返回False和None
                        return False, None
                    target_info.is_known = True
                    if person.person_id:
                        target_info.person_id = person.person_id
                        target_info.person_name = person.person_name
                except Exception as person_e:
                    logger.warning(
                        f"获取 person_id 或 person_name 时出错 for {platform}:{user_id} in utils: {person_e}"
                    )

                chat_target_info = target_info
        else:
            logger.warning(f"无法获取 chat_stream for {chat_id} in utils")
    except Exception as e:
        logger.error(f"获取聊天类型和目标信息时出错 for {chat_id}: {e}", exc_info=True)

    return is_group_chat, chat_target_info


def record_replyer_action_temp(chat_id: str, reason: str, think_level: int) -> None:
    """
    临时记录replyer动作被选择的信息（仅群聊）

    Args:
        chat_id: 聊天ID
        reason: 选择理由
        think_level: 思考深度等级
    """
    try:
        # 确保data/temp目录存在
        temp_dir = "data/temp"
        os.makedirs(temp_dir, exist_ok=True)

        # 创建记录数据
        record_data = {
            "chat_id": chat_id,
            "reason": reason,
            "think_level": think_level,
            "timestamp": datetime.now().isoformat(),
        }

        # 生成文件名（使用时间戳避免冲突）
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"replyer_action_{timestamp_str}.json"
        filepath = os.path.join(temp_dir, filename)

        # 写入文件
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(record_data, f, ensure_ascii=False, indent=2)

        logger.debug(f"已记录replyer动作选择: chat_id={chat_id}, think_level={think_level}")
    except Exception as e:
        logger.warning(f"记录replyer动作选择失败: {e}")


def assign_message_ids(messages: List[SessionMessage]) -> List[Tuple[str, SessionMessage]]:
    """
    为消息列表中的每个消息分配唯一的简短随机ID

    Args:
        messages: 消息列表

    Returns:
        List[SessionMessage]: 分配了唯一ID的消息列表
    """
    result: List[Tuple[str, SessionMessage]] = []  # 复制原始消息列表
    used_ids = set()
    len_i = len(messages)
    if len_i > 100:
        a = 10
        b = 99
    else:
        a = 1
        b = 9

    for i, message in enumerate(messages):
        # 生成唯一的简短ID
        while True:
            # 使用索引+随机数生成简短ID
            random_suffix = random.randint(a, b)
            message_id = f"m{i + 1}{random_suffix}"

            if message_id not in used_ids:
                used_ids.add(message_id)
                break
        result.append((message_id, message))

    return result


#                 break
#         result.append((message_id, message))

#     return result


def parse_keywords_string(keywords_input) -> list[str]:
    # sourcery skip: use-contextlib-suppress
    """
    统一的关键词解析函数，支持多种格式的关键词字符串解析

    支持的格式：
    1. 字符串列表格式：'["utils.py", "修改", "代码", "动作"]'
    2. 斜杠分隔格式：'utils.py/修改/代码/动作'
    3. 逗号分隔格式：'utils.py,修改,代码,动作'
    4. 空格分隔格式：'utils.py 修改 代码 动作'
    5. 已经是列表的情况：["utils.py", "修改", "代码", "动作"]
    6. JSON格式字符串：'{"keywords": ["utils.py", "修改", "代码", "动作"]}'

    Args:
        keywords_input: 关键词输入，可以是字符串或列表

    Returns:
        list[str]: 解析后的关键词列表，去除空白项
    """
    if not keywords_input:
        return []

    # 如果已经是列表，直接处理
    if isinstance(keywords_input, list):
        return [str(k).strip() for k in keywords_input if str(k).strip()]

    # 转换为字符串处理
    keywords_str = str(keywords_input).strip()
    if not keywords_str:
        return []

    try:
        # 尝试作为JSON对象解析（支持 {"keywords": [...]} 格式）
        json_data = json.loads(keywords_str)
        if isinstance(json_data, dict) and "keywords" in json_data:
            keywords_list = json_data["keywords"]
            if isinstance(keywords_list, list):
                return [str(k).strip() for k in keywords_list if str(k).strip()]
        elif isinstance(json_data, list):
            # 直接是JSON数组格式
            return [str(k).strip() for k in json_data if str(k).strip()]
    except (json.JSONDecodeError, ValueError):
        pass

    try:
        # 尝试使用 ast.literal_eval 解析（支持Python字面量格式）
        parsed = ast.literal_eval(keywords_str)
        if isinstance(parsed, list):
            return [str(k).strip() for k in parsed if str(k).strip()]
    except (ValueError, SyntaxError):
        pass

    # 尝试不同的分隔符
    separators = ["/", ",", " ", "|", ";"]

    for separator in separators:
        if separator in keywords_str:
            keywords_list = [k.strip() for k in keywords_str.split(separator) if k.strip()]
            if len(keywords_list) > 1:  # 确保分割有效
                return keywords_list

    # 如果没有分隔符，返回单个关键词
    return [keywords_str] if keywords_str else []


