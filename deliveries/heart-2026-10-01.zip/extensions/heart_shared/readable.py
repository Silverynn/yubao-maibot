"""面向日常查看的中文日志；内部编号、JSON、排序分数只保留在数据库。"""

import json
import re
from datetime import datetime


def plain(value, limit=600):
    if not isinstance(value, str):
        return ""
    text = re.sub(r"(?:[A-Za-z_]+:)?[0-9a-fA-F]{24,}", "[内部编号已省略]", value)
    text = " ".join(text.split())
    if text.startswith(("{", "[")):
        try:
            structured = json.loads(value)
        except ValueError:
            pass
        else:
            values = contents(structured)
            return "；".join(values)[:limit] if values else "结构化详情已保留后台"
    return text[:limit] + ("…（内容较长，已节选）" if len(text) > limit else "")


def contents(value):
    """只选取可读正文，不遍历 metadata 等内部字段。"""
    if isinstance(value, list):
        return [text for item in value for text in contents(item)]
    if not isinstance(value, dict):
        return []
    result = []
    for key in ("content", "text", "summary", "profile_text"):
        text = value.get(key)
        if isinstance(text, str) and text.strip():
            result.append(plain(text))
    for key in ("hits", "facts", "claims", "paragraphs", "items"):
        if isinstance(value.get(key), list):
            result.extend(contents(value[key]))
    return list(dict.fromkeys(result))


def number(value):
    return f"{value:.1f}".removesuffix(".0") if isinstance(value, (int, float)) else "未知"


def session_label(data):
    """显示聊天流名称，避免把不同会话的心情值读成一次跳变。"""
    dialogue = data.get("dialogue") or []
    name = plain(data.get("session_name") or (dialogue[-1].get("name", "") if dialogue else ""), 80)
    if " / " in name:
        return "群聊 " + name.rsplit(" / ", 1)[0]
    return "与" + name + "的会话" if name else "名称未记录"


def render_event(event, data):
    kind = event["kind"]
    mood = data.get("mood") or {}
    dialogue = data.get("dialogue") or []
    names = list(dict.fromkeys(plain(m.get("name", ""), 80) for m in dialogue if m.get("name")))
    if not names and mood.get("trigger", {}).get("name"):
        names = [plain(mood["trigger"]["name"], 80)]
    timestamp = datetime.fromisoformat(event["time"]).strftime("%Y-%m-%d %H:%M:%S")
    lines = [f"#{event['seq']} 时间：{timestamp}｜{kind}",
             f"会话：{session_label(data)}（心情按会话分别计算）",
             f"人物：{'、'.join(names) or '后台操作（未明确关联人物）'}"]
    relation = data.get("relation", "")
    if dialogue and relation != "证据消息ID关联":
        lines.append("说明：以下人物和对话仅供上下文参考，不能确定为此次调用的触发来源。")
    if mood.get("value") is None:
        lines.append("心情：暂无可关联的记录")
    elif kind == "心情变化":
        lines.append(f"心情：{number(mood.get('before'))} → {number(mood['value'])} / 100")
    else:
        lines.append(f"心情：{number(mood['value'])} / 100")
    emotion = data.get("emotion") or {}
    if emotion.get("active"):
        lines.append(f"临时情绪：{plain(emotion.get('label', ''))}（强度{number(emotion.get('intensity', 0) * 100)}%）；话题：{plain(emotion.get('topic', ''))}")
    if kind == "心情变化":
        lines += ["调用：心情插件 · 已更新状态", "触发对话：" + ('本批合并评估，逐条见下方' if mood.get('batch_count') else plain(mood.get("trigger", {}).get("text", "")))]
        if mood.get('batch_count'):
            lines.append(f"会话合并评估：{mood['batch_count']}条发言共同判断一次；不是最后一个人的单独评分。")
            for item in dialogue:
                lines.append('本批发言：'+plain(item.get('name',''),80)+'：'+plain(item.get('text',''),500))
        recovery = mood.get("recovery", 0)
        target = mood.get("recovery_target")
        elapsed = mood.get("recovery_elapsed_seconds")
        rate = mood.get("recovery_per_hour")
        if recovery and isinstance(target, (int, float)) and isinstance(elapsed, (int, float)) and isinstance(rate, (int, float)):
            hours = elapsed / 3600
            lines.append(f"数值变化原因：距上次结算约{number(hours)}小时，按每小时{number(rate)}分向当前恢复目标{number(target)}靠近，时间恢复{number(recovery)}分；与本条对话的AI判断分开计算。")
        elif recovery:
            lines.append(f"数值变化原因：时间恢复{number(recovery)}分；旧记录缺少恢复目标和间隔，不能从日志确定更具体的原因。")
        previous_target = mood.get("previous_recovery_target")
        if isinstance(previous_target, (int, float)) and isinstance(target, (int, float)) and previous_target != target:
            lines.append(f"配置变化：上次记录的恢复目标为{number(previous_target)}，本次为{number(target)}；本次把上次结算以来的间隔按新目标计算，无法确定配置具体何时改动。")
        if recovery:
            lines.append("说明：单条对话的变化上限只约束情绪刺激；时间恢复按经过时长另行结算。重启本身不会重置已有心情。")
        assessment = mood.get("assessment") or {}
        lines.append("判断方式：" + plain(assessment.get("method", "关键词")))
        lines.append("判断原因：" + plain(assessment.get("reason", mood.get("reason", ""))))
        lines.append(f"建议刺激：{number(mood.get('proposed_delta'))}；限幅/冷却后刺激：{number(mood.get('stimulus_delta'))}；时间恢复：{number(mood.get('recovery'))}；实际总变化：{number(mood.get('actual_delta'))}")
        if "confidence" in assessment:
            lines.append(f"AI把握程度：{number(assessment['confidence'] * 100)}%；AI原始建议：{number(assessment.get('model_delta'))}")
        if "multiplier" in assessment:
            lines.append(f"强度设置：倍率{number(assessment['multiplier'])}；倍率后建议{number(assessment.get('scaled_delta'))}；AI上限加{number(assessment.get('positive_limit'))}/减{number(assessment.get('negative_limit'))}")
        diagnostics = assessment.get("diagnostics") or {}
        if 'queue_ms' in assessment:
            lines.append(f"评估耗时：排队{number(assessment['queue_ms'] / 1000)}秒；本轮处理{number(assessment.get('duration_ms', 0) / 1000)}秒（超时或暂停不代表AI已判断）")
        if "response_chars" in diagnostics:
            lines.append(f"AI返回：正文{number(diagnostics['response_chars'])}字符；输出用量{number(diagnostics.get('output_units_used'))} / 预算{number(diagnostics.get('output_budget'))}（不是心情分数）")
    elif kind == "心情初始化":
        lines.append("调用：心情插件 · " + plain(data.get("reason", "")))
    elif kind in ("临时情绪产生", "临时情绪变化", "临时情绪结束", "临时情绪判断"):
        previous = data.get("previous_emotion") or {}
        if previous.get("active"):
            lines.append("原情绪：" + plain(previous.get("label", "")) + "；原话题：" + plain(previous.get("topic", "")))
        lines.append("调用：话题情绪 · " + ("已结束，恢复当前心情对应的常态" if kind == "临时情绪结束" else plain(data.get("status", "已保存"))))
        lines.append("原因：" + plain(data.get("reason", emotion.get("reason", ""))))
        if dialogue and relation == "证据消息ID关联":
            lines.append("触发对话：" + "；".join(plain(m.get("text", "")) for m in dialogue))
        lines.append("说明：临时情绪分类不会直接加减心情分数；不按秒数自动消失。")
    elif kind in ('表情表演请求', '表情请求判断'):
        lines.append('调用：自然语言表情判断 · ' + plain(data.get('status', '')))
        if data.get('expression'):
            lines.append('目标表情：' + plain(data['expression']))
        lines.append('原因：' + plain(data.get('reason', '')))
        if dialogue and relation == '证据消息ID关联':
            lines.append('触发对话：' + '；'.join(plain(m.get('text', '')) for m in dialogue))
        lines.append('说明：这是外观表演请求，不代表真实情绪改变；动作是否执行看前端回执。')
    elif kind == "Live2D动作":
        lines.append("调用：Live2D表情接口 · " + plain(data.get("status", "")))
        lines.append("目标表情：" + plain(data.get("expression", "")))
        lines.append("原因：" + plain(data.get("reason", "")))
        if data.get("status") == "前端报告：已执行表情设置":
            lines.append("说明：表情设置代码已执行；这不等于人眼或截图确认。")
        else:
            lines.append("说明：此条不表示表情已成功执行，请查看后续执行回执；首次加载模型时可能暂不可用。")
    elif kind == "AI心情评估跳过":
        lines.append("调用：AI心情判断 · " + plain(data.get("reason", "未完成")))
    elif kind == "心情影响回复风格":
        band = {"low": "安静克制", "neutral": "平和自然", "high": "轻快温暖"}.get(data.get("band"), "当前设定")
        if data.get("style_name"):
            band = plain(data["style_name"], 30)
        lines.append(f"调用：心情插件 · 已使用“{band}”风格要求（实际效果看回复）")
        if data.get("assessment_pending"):
            lines.append("状态说明：本轮AI评估尚未完成，回复使用最近已确认的情绪，不假装已经更新。")
        if 'emotion_wait_ms' in data:
            lines.append(f"回复等待心情评估：{number(data['emotion_wait_ms'] / 1000)}秒；" + ('回复优先已开启' if data.get('reply_first') else '按配置等待'))
    elif kind == "收到对话":
        lines += ["对话：" + plain(data.get("text", "")), "调用：对话记录 · 已记录，记忆结果如有产生会另记"]
    elif kind == "记忆操作结果":
        lines.extend(render_memory(data))
    elif kind == "后台记忆管理":
        lines.append("调用：WebUI原生记忆管理 · " + plain(data.get("status", "")))
        lines.append("操作者：" + plain(data.get("reviewer", "WebUI管理员")) + "（不等于用户本人确认）")
        for text in data.get("old_memories", []):
            lines.append("旧记忆：" + plain(text))
        lines.append("新记忆：" + plain(data.get("new_memory", "")))
        lines.append("修改原因：" + plain(data.get("reason", "")))
    elif kind == "记忆冲突确认":
        lines.append("调用：记忆冲突保护 · " + plain(data.get("status", "")))
        for text in data.get("old_memories", []):
            lines.append("旧记忆：" + plain(text))
        lines.append("新内容：" + plain(data.get("new_memory", "")))
        if data.get("reason"):
            lines.append("说明：" + plain(data["reason"]))
    elif kind == "摘要去重判断":
        lines.append("调用：会话摘要去重 · " + plain(data.get("status", "")))
        if data.get("new_memory"):
            lines.append("本次摘要：" + plain(data["new_memory"]))
        if data.get("old_memories"):
            for text in data["old_memories"]:
                lines.append("判定相关的旧摘要：" + plain(text))
        if data.get("candidate_memories"):
            lines.append("本次比较候选（不代表重复）：")
            for index, text in enumerate(data['candidate_memories']):
                lines.append(f"  {index+1}. " + plain(text))
                scores = (data.get('retrieval_scores') or [])
                if index < len(scores):
                    vector = scores[index].get('vector')
                    if isinstance(vector,(int,float)):
                        lines.append(f"     向量相似度：{vector:.3f}（用于召回，不是同义概率）")
        if data.get('confidence') is not None:
            lines.append(f"AI判断把握：{data['confidence']:.0%}")
        if data.get('new_text') and data.get('new_text') != data.get('new_memory'):
            lines.append("仅保留的新增内容：" + plain(data['new_text']))
        if data.get('recall_note'):
            lines.append("候选来源：" + plain(data['recall_note']))
        lines.append("判断依据：" + plain(data.get("reason", "")))
    elif kind == "记忆去重":
        lines.append("调用：长期记忆去重 · " + plain(data.get("status", "")))
        lines.append("准备写入：" + plain(data.get("new_memory", "")))
        for text in data.get("old_memories", []):
            lines.append("已有记忆：" + plain(text))
        if data.get("reason"):
            lines.append("判断依据：" + plain(data["reason"]))
        lines.append("结果：旧记忆保留；本次没有新增长期记忆。")
    elif kind == "候选记忆":
        lines.append(f"调用：候选记忆 · #{data.get('candidate_id', '?')} · " + plain(data.get("status", "")))
        lines.append("候选内容：" + plain(data.get("new_memory", "")))
        if data.get("reason"):
            lines.append("说明：" + plain(data["reason"]))
    elif kind == "自动记忆判断":
        memories = data.get("memories") or []
        lines.append("调用：原生AI记忆筛选 · " + plain(data.get("status", "")))
        for memory in memories[:5]:
            lines.append("筛出内容：" + plain(memory))
        if memories:
            lines.append("说明：筛出内容尚不等于写入长期记忆；请查看后续候选或原生写入结果。")
    elif kind == "手动记忆请求":
        lines.append("调用：/记住 · " + plain(data.get("status", "")))
        lines.append("请求内容：" + plain(data.get("new_memory", "")))
        if data.get("detail"):
            lines.append("说明：" + plain(data["detail"]))
    elif kind == "忘记记忆":
        lines.append("调用：/我的记忆 或 /忘记 · " + plain(data.get("status", "")))
        if data.get("memory"):
            lines.append("目标记忆：" + plain(data["memory"]))
        if data.get("reason"):
            lines.append("说明：" + plain(data["reason"]))
    elif kind == "群聊记忆管理":
        actions = {"list": "查看本人长期记忆", "forget": "申请忘记本人记忆",
                   "natural_forget": "自然语言申请忘记", "查看候选记忆": "查看本人候选记忆"}
        lines.append("调用：群聊记忆管理 · " + actions.get(data.get("action"), "本人记忆操作"))
        lines.append("结果：" + plain(data.get("status", "")))
        lines.append("隐私：群里只显示回执；记忆正文及删除确认留在本人私聊。")
    elif kind == '记忆冲突候选检索':
        lines.append('调用：新事实写入前的旧记忆检索 · '+plain(data.get('status', '')))
        lines.append('准备写入：'+plain(data.get('new_memory', '')))
        for old in (data.get('old_memories') or [])[:5]:
            lines.append('比较旧记忆：'+plain(old))
        lines.append('说明：只比较同一会话、同一人物的有效事实；检索到不代表发生冲突。')
    elif kind == "群聊记忆检索":
        hits = data.get("hits") or []
        lines.append("调用：当前群聊的长期记忆检索 · " + plain(data.get("status", "")))
        if data.get("target_name"):
            lines.append("查看对象：@" + plain(data["target_name"], 40))
        lines.append("查询：" + plain(data.get("query", "")))
        if data.get("target_name") and isinstance(data.get("candidate_count"), int):
            lines.append(f"结果核对：原生返回{data['candidate_count']}条候选，确认同时属于该成员和本群的有{len(hits)}条。")
        types = data.get('hit_types') or []
        for index, hit in enumerate(hits, 1):
            label = ('['+types[index-1]+'] ') if index-1 < len(types) else ''
            lines.append(f"群聊命中 {index}：" + label + plain(hit))
        lines.append("说明：仅展示本群可见且归属可核实的内容；未读取成员私聊记忆。" if data.get("target_name")
                     else "说明：只检索当前群聊可见范围；未读取成员私聊记忆。")
    elif kind == "模型请求中的记忆参考":
        refs = data.get("references") or []
        stage = "思考阶段" if data.get("stage") == "planner" else "回复阶段"
        lines.append(f"调用：记忆参考观察 · {stage} · {'发现记忆参考，不代表最终采用' if refs else '未发现可识别的记忆参考'}")
        for ref in refs[:3]:
            lines.append("参考内容：" + plain(ref.get("text", "")))
        if len(refs) > 3:
            lines.append(f"另有 {len(refs) - 3} 段参考，完整内容保留后台。")
    elif kind in ("生成回复（尚非送达）", "发送结果"):
        state = ("发送成功（不表示已读）" if data.get("sent") else "发送失败") if kind == "发送结果" else "回复已生成，尚非送达"
        lines += ["调用：回复观察 · " + state, "机器人回复：" + plain(data.get("response", ""))]
    else:
        lines.append("调用：已记录；详细参数保留后台")
    if kind == "记忆操作结果" and dialogue:
        lines.append("相关对话：" + "；".join(plain(m.get("text", ""), 200) for m in dialogue[-2:]))
    return "\n".join(lines)


def render_memory(data):
    outcome = data.get("outcome") or {}
    operation = data.get("operation", "")
    labels = {"search_memory": "检索记忆", "ingest_text": "存储人物事实/文本", "ingest_summary": "存储摘要",
              "get_person_profile": "读取人物画像", "memory_profile_admin": "人物画像操作",
              "maintain_memory": "记忆维护", "memory_delete_admin": "记忆删除操作",
              "memory_fact_admin": "人物事实操作", "memory_correction_admin": "记忆纠正操作",
              "enqueue_feedback_task": "安排记忆反馈检查"}
    title = "调用：记忆插件 · " + labels.get(operation, "后台记忆操作")
    if isinstance(data.get("duration_ms"), (int, float)):
        title += f" · 耗时 {data['duration_ms'] / 1000:.2f} 秒"
    lines = [title]
    result = outcome.get("result") or {}
    error = outcome.get("error") or (result.get("error") if isinstance(result, dict) else "")
    if operation == "ingest_text" and outcome.get("status", "").startswith(("候选待确认", "冲突待确认")):
        lines.append("结果：" + outcome["status"])
        lines.append("待处理内容：" + plain(outcome.get("submitted_text", "")))
        return lines
    if error or "失败" in outcome.get("status", ""):
        reason = "等待超时" if "timeout" in str(error).lower() else "调用未成功，详细错误保留后台"
        lines.append("结果：未成功 · " + reason)
        if outcome.get("submitted_text"):
            lines.append("待写入内容：" + plain(outcome["submitted_text"]))
        if outcome.get("detail"):
            lines.append("说明：" + plain(outcome["detail"]))
        return lines
    if operation in {"search_memory", "heart_scoped_list"}:
        hits = outcome.get("hits") or []
        lines += ["查询：" + plain(outcome.get("query", "")), f"记忆：检索返回 {len(hits)} 条候选（不代表最终采用）"]
        if outcome.get('scope_note'):
            lines.append('可见范围：'+plain(outcome['scope_note'])+f"；排除 {outcome.get('scope_removed_count', 0)} 条非本会话/来源不明内容")
        for index, hit in enumerate(hits[:5], 1):
            metadata = hit.get("metadata") or {}
            source = str(metadata.get("source_type") or hit.get("type") or "") if isinstance(metadata, dict) else ""
            source_name = {"person_fact": "人物事实", "paragraph": "文字记忆", "episode": "经历",
                           "relation": "关系", "chat_summary": "聊天摘要"}.get(source, "记忆")
            lines.append(f"  {index}. [{source_name}] {plain(hit.get('content', ''))}")
        if len(hits) > 5:
            lines.append(f"  另有 {len(hits) - 5} 条候选，完整内容保留后台。")
    elif operation in {"ingest_text", "ingest_summary"}:
        stored, skipped = outcome.get("stored_ids") or [], outcome.get("skipped_ids") or []
        saved = outcome.get('stored_contents') or []
        if saved:
            lines.append(f'结果：已在原生记忆库核对到 {len(saved)} 条正文')
            for text in saved:
                lines.append('实际存储：'+plain(text))
        elif stored:
            lines.append(f"结果：服务报告已存储 {len(stored)} 条（可能包含更新，不保证都是新增）")
        elif skipped:
            lines.append(f"结果：跳过 {len(skipped)} 条，本次未报告新存储")
        else:
            lines.append("结果：未确认存储成功")
        if outcome.get('submitted_text'):
            lines.append("提交内容：" + plain(outcome['submitted_text']))
        if outcome.get('detail'):
            lines.append('原生结果：'+plain(outcome['detail']))
    else:
        lines.append("结果：服务已返回；具体效果以原生记忆系统为准")
        for text in contents(result)[:5]:
            lines.append("记忆内容：" + text)
    return lines


def render_status(detail, index):
    trigger = detail.get("trigger") or {}
    lines = [f"人物/聊天 {index}：{plain(trigger.get('name', '未命名聊天'), 80)}",
             f"心情：{number(detail.get('before'))} → {number(detail.get('value'))} / 100"]
    if detail.get("recovery"):
        lines.append(f"时间恢复：{number(detail['recovery'])}分，向当前目标{number(detail.get('recovery_target'))}靠近；本条对话刺激{number(detail.get('stimulus_delta'))}分")
    lines.extend(["对话判断原因：" + plain(detail.get("reason", "")),
                  "触发对话：" + plain(trigger.get("text", "")), ""])
    return lines
